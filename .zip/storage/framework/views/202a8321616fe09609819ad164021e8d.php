<div aria-label="breadcrumb">
    <ol class="breadcrumb">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="breadcrumb-item <?php if($loop->last): ?> active <?php endif; ?>" <?php if($loop->last): ?> aria-current="page" <?php endif; ?>>
                <?php if($loop->last): ?>
                    <?php echo e($item['label']); ?>

                <?php else: ?>
                    <a href="<?php echo e($item['url']); ?>"><?php echo e($item['label']); ?></a>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</div><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>