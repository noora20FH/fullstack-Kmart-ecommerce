<?php
return [
    'api_key' => 'QuD0kpti57bcb8552759f9f9mtAc73cA'
];
