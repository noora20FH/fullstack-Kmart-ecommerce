<?php if (isset($component)) { $__componentOriginal0dc051632a3fa4a4e85488840d04371b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0dc051632a3fa4a4e85488840d04371b = $attributes; } ?>
<?php $component = App\View\Components\Authlayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('authlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Authlayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Session Status -->
    <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

    
    <!-- Bagian Komponen Register yang baru ditambahkan -->
    <div class="w-100 p-md-4 p-3" style="max-width: 450px;">
        <div class="mb-3 text-end">
            <a href="<?php echo e(route('login')); ?>" class="text-decoration-none text-muted">Login</a>
        </div>
        <h3 class="mb-3 text-center fw-semibold">Register</h3>
        <p class="text-center text-muted mb-4">Create your account to get started</p>
        
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            
            <!-- Name -->
            <div class="mb-3">
                <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
                <input id="name" class="form-control" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus autocomplete="name" placeholder="Full Name" />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <!-- Email Address -->
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
                <input id="email" class="form-control" type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="username" placeholder="name@example.com" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <!-- Password -->
            <div class="mb-3">
                <label for="password" class="form-label"><?php echo e(__('Password')); ?></label>
                <input id="password" class="form-control" type="password" name="password" required autocomplete="new-password" placeholder="password" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <!-- Confirm Password -->
            <div class="mb-4">
                <label for="password_confirmation" class="form-label"><?php echo e(__('Confirm Password')); ?></label>
                <input id="password_confirmation" class="form-control" type="password" name="password_confirmation" required autocomplete="new-password" placeholder="confirm password" />
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary btn-lg">
                    <?php echo e(__('Register')); ?>

                </button>
            </div>
        </form>
        
        <div class="d-flex align-items-center text-center text-muted my-4">
            <span class="flex-grow-1 border-bottom border-secondary-subtle"></span>
            <span class="mx-2">OR CONTINUE WITH</span>
            <span class="flex-grow-1 border-bottom border-secondary-subtle"></span>
        </div>
        
        <div class="d-grid">
            <button class="btn btn-light btn-lg border d-flex justify-content-center align-items-center fw-medium">
                <img src="https://www.google.com/favicon.ico" alt="Google icon" class="me-2" style="width: 20px; height: 20px;">
                Google
            </button>
        </div>

        <div class="mt-4 text-center text-secondary" style="font-size: 0.8rem;">
            By clicking continue, you agree to our 
            <a href="#" class="text-decoration-none text-muted">Terms of Service</a> 
            and 
            <a href="#" class="text-decoration-none text-muted">Privacy Policy</a>.
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0dc051632a3fa4a4e85488840d04371b)): ?>
<?php $attributes = $__attributesOriginal0dc051632a3fa4a4e85488840d04371b; ?>
<?php unset($__attributesOriginal0dc051632a3fa4a4e85488840d04371b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0dc051632a3fa4a4e85488840d04371b)): ?>
<?php $component = $__componentOriginal0dc051632a3fa4a4e85488840d04371b; ?>
<?php unset($__componentOriginal0dc051632a3fa4a4e85488840d04371b); ?>
<?php endif; ?>
<?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>