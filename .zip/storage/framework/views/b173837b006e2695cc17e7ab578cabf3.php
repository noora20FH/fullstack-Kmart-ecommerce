<?php if (isset($component)) { $__componentOriginalfbdd260259317c02d12d73257650e0d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbdd260259317c02d12d73257650e0d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mainlayout','data' => ['title' => 'K-Pop Mart Checkout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mainlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'K-Pop Mart Checkout']); ?>
    <main class="container my-5">
        <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['items' => [
            ['label' => 'Keranjang', 'url' => route('cart.index')],
            ['label' => 'Checkout', 'url' => route('checkout.index')],
        ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

        <h1 class="mb-4">Checkout</h1>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm p-3">
                    <h5 class="mb-3">Item yang Dipilih</h5>
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" class="text-center">Harga</th>
                                    <th scope="col" class="text-center">Jumlah</th>
                                    <th scope="col" class="text-end">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $checkoutItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo e(asset('storage/image/' . $item->product->image)); ?>" class="cart-item-img rounded me-3" width="150px" alt="<?php echo e($item->product->name); ?>">
                                            <div>
                                                <h6 class="mb-0"><?php echo e($item->product->name); ?></h6>
                                                <small class="text-muted"><?php echo e(Str::limit($item->product->description, 30)); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center">Rp <?php echo e(number_format($item->product->price, 0, ',', '.')); ?></td>
                                    <td class="text-center"><?php echo e($item->quantity); ?></td>
                                    <td class="text-end fw-bold">Rp <?php echo e(number_format($item->product->price * $item->quantity, 0, ',', '.')); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center">Tidak ada item untuk checkout.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="card shadow-sm p-4">
                    <h5 class="mb-3">Ringkasan Pesanan</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            Subtotal
                            <span class="fw-bold">Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            Pengiriman
                            <span>Rp <?php echo e(number_format($shipping, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            Pajak
                            <span>Rp <?php echo e(number_format($tax, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0 fw-bold">
                            Total
                            <span class="fs-4 text-kpop-accent">Rp <?php echo e(number_format($total, 0, ',', '.')); ?></span>
                        </li>
                    </ul>

                    <div class="d-grid gap-2 mt-4">
                        <a class="btn btn-kpop btn-lg" href="<?php echo e(route('checkout.processPayment')); ?>">Lanjut ke Pembayaran</a>
                        <a class="btn btn-outline-secondary" href="<?php echo e(route('products.index')); ?>">Lanjutkan Belanja</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $attributes = $__attributesOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__attributesOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $component = $__componentOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__componentOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/checkout.blade.php ENDPATH**/ ?>