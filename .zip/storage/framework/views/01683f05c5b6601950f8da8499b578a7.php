<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: var(--primary-color);">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>" style="color: #fff; font-weight: bold;">
            <img src="<?php echo e(asset('image/logo.png')); ?>" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php if(
                (Auth::check() && (Auth::user()->role === 'customer')) ||
                (!Auth::check())
                ): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('products.index') ? 'active' : ''); ?>" href="<?php echo e(route('products.index')); ?>">Produk</a>
                </li>

                <li class="nav-item">
                    <!-- Untuk link anchor, kita cek URL. -->
                    <a class="nav-link <?php echo e(Request::is('/') && request()->url() . '#faq-section' == url('/#faq-section') ? 'active' : ''); ?>" href="<?php echo e(url('/#faq-section')); ?>">FAQ</a>
                </li>
                <li class="nav-item">
                    <!-- Untuk link anchor, kita cek URL. -->
                    <a class="nav-link <?php echo e(Request::is('/') && request()->url() . '#about-us' == url('/#about-us') ? 'active' : ''); ?>" href="<?php echo e(url('/#about-us')); ?>">Tentang Kami</a>
                </li>
                <li>
                    <a class="nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="<?php echo e(route('checkout.index')); ?>">Checkout</a>
                </li>
                <?php endif; ?>
                <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin-products.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin-products.index')); ?>">Product List</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('product-category.index') ? 'active' : ''); ?>" href="<?php echo e(route('product-category.index')); ?>">Product Category</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('admin.orders.index') ? 'active' : ''); ?>" href="<?php echo e(route('admin.orders.index')); ?>">Status Order</a>
                </li>
                <?php endif; ?>
            </ul>
            <?php if(auth()->guard()->check()): ?>
            <div class="d-flex gap-2">
                <?php if(Auth::user()->role === 'customer'): ?>
                <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-outline-light">
                    <i class="bi bi-cart"></i>
                </a>
                <?php endif; ?>
                <div class="dropdown">
                    <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i> <?php echo e(Auth::user()->name); ?>

                    </button>
                    <ul class="dropdown-menu dropdown-menu-end p-2">
                        <!-- Informasi Profil Dinamis -->
                        <li class="profile-info d-flex align-items-center mb-2 px-3">
                            <?php
                            $extensions = ['png', 'jpg', 'jpeg', 'webp'];
                            $photoFound = false;
                            ?>

                            <?php $__currentLoopData = $extensions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ext): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(file_exists(public_path('storage/profiles/' . Auth::user()->id . '.' . $ext))): ?>
                            <img src="<?php echo e(asset('storage/profiles/' . Auth::user()->id . '.' . $ext)); ?>" alt="Profile Photo" class="profile-photo rounded-circle me-2">
                            <?php $photoFound = true; break; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(!$photoFound): ?>
                            
                            <img src="<?php echo e(asset('image/logo.png')); ?>" alt="Default Profile Photo" class="profile-photo rounded-circle me-2" style="width: 40px">
                            <?php endif; ?>
                            <div>
                                <h6 class="mb-0"><?php echo e(Auth::user()->name); ?></h6>
                                <p class="text-muted mb-0" style="font-size: 0.875em;"><?php echo e(Auth::user()->email); ?></p>
                            </div>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <!-- Tautan -->
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('profile.edit', ['profile' => Auth::user()->id])); ?>">
                                <i class="bi bi-person me-2"></i>Edit Profile
                            </a>
                        </li>
                        <?php if(Auth::user()->role === 'customer'): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('orders.index')); ?>"><i class="bi bi-box-seam me-2"></i>Riwayat Pesanan</a></li>
                        <?php endif; ?>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <!-- Tautan Logout -->
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <a class="dropdown-item text-danger" href="<?php echo e(route('home')); ?>"
                                    onclick="event.preventDefault(); this.closest('form').submit();">
                                    <i class="bi bi-box-arrow-right text-danger me-2"></i>Logout
                                </a>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            <?php endif; ?>

            <!-- Bagian ini akan muncul HANYA jika pengguna BELUM login -->
            <?php if(auth()->guard()->guest()): ?>
            <div class="d-flex">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light mx-1">Masuk</a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-light mx-1">Daftar</a>
            </div>
            <?php endif; ?>


        </div>
    </div>
</nav><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/partials/navbar.blade.php ENDPATH**/ ?>