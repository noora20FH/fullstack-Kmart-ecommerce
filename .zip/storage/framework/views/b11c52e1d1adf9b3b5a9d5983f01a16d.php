<?php if (isset($component)) { $__componentOriginalfbdd260259317c02d12d73257650e0d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbdd260259317c02d12d73257650e0d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mainlayout','data' => ['title' => 'K-Pop Mart Checkout']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mainlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'K-Pop Mart Checkout']); ?>

    <main class="container my-5">
        <?php
        $items = [
        ['label' => 'Produk', 'url' => route('products.index')],
        ['label' => 'Cart', 'url' => route('cart.index')],
        ['label' => 'Checkout', 'url' => '#'],
        ];
        ?>

        <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['items' => $items] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
        <h1 class="mb-4">Checkout</h1>

        <div class="row g-4">
            <div class="col-lg-8">
                <!-- Informasi Pengiriman -->
                <div class="card shadow-sm p-4 mb-4">
                    <h5 class="mb-4">Informasi Pengiriman</h5>
                    <div class="mb-3">
                        <p class="mb-1"><strong>Nama Lengkap:</strong> <?php echo e($checkout->user->name ?? 'N/A'); ?></p>
                        <p class="mb-1"><strong>Nomor HP:</strong> <?php echo e($checkout->user->phone ?? 'N/A'); ?></p>
                        <p class="mb-0"><strong>Alamat Pengiriman:</strong> <?php echo e($checkout->user->address ?? 'N/A'); ?></p>
                    </div>
                </div>

                <!-- Cari Tujuan Pengiriman -->
                <!-- <div class="card shadow-sm p-4 mb-4">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('princing-check');

$__html = app('livewire')->mount($__name, $__params, 'lw-1936362802-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                </div> -->

                <!-- Detail Pesanan -->
                <div class="card shadow-sm p-4 mb-4">
                    <h5 class="mb-4">Detail Pesanan</h5>
                    <div class="list-group list-group-flush">
                        <?php if($checkout && $checkout->checkoutItems): ?>
                        <?php $__empty_1 = true; $__currentLoopData = $checkout->checkoutItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="list-group-item card-product-detail d-flex align-items-center justify-content-between py-3">
                            <div class="d-flex align-items-center">
                                <img src="<?php echo e(asset('storage/image/' . $item->product->image)); ?>" alt="<?php echo e($item->product->name); ?>" class="me-3" width="80px" height="80px">
                                <div>
                                    <h6 class="mb-0"><?php echo e($item->product->name); ?></h6>
                                    <small class="text-muted">Harga satuan: Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></small>
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="me-4 text-muted"><?php echo e($item->quantity); ?>x</span>
                                <span class="fw-bold">Rp <?php echo e(number_format($item->price * $item->quantity, 0, ',', '.')); ?></span>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="list-group-item">
                            Tidak ada item dalam pesanan ini.
                        </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <div class="list-group-item">
                            Data pesanan tidak ditemukan.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Metode Pembayaran -->
                <!-- <div class="card shadow-sm p-4">
                    <h5 class="mb-4">Pilih Metode Pembayaran</h5>
                    <div class="my-3">
                        <div class="form-check mb-2">
                            <input id="credit" name="paymentMethod" type="radio" class="form-check-input" checked required>
                            <label class="form-check-label" for="credit">
                                <i class="fas fa-credit-card me-2"></i> Kartu Kredit / Debit
                            </label>
                        </div>
                        <div class="form-check mb-2">
                            <input id="bank" name="paymentMethod" type="radio" class="form-check-input" required>
                            <label class="form-check-label" for="bank">
                                <i class="fas fa-university me-2"></i> Bank Transfer
                            </label>
                        </div>
                        <div class="form-check">
                            <input id="ewallet" name="paymentMethod" type="radio" class="form-check-input" required>
                            <label class="form-check-label" for="ewallet">
                                <i class="fas fa-wallet me-2"></i> E-wallet (DANA, OVO, GoPay)
                            </label>
                        </div>
                    </div>
                </div> -->
            </div>

            <!-- Ringkasan Pesanan -->
            <div class="col-lg-4">
                <div class="card shadow-sm p-4 sticky-top" style="top: 2rem;">
                    <h5 class="mb-3">Ringkasan Pesanan</h5>
                    <ul class="list-group list-group-flush card-order-summary">
                        <li class="list-group-item d-flex justify-content-between">
                            <strong>Subtotal Produk</strong>
                            <span>Rp <?php echo e(number_format($summary->subtotal ?? 0, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <strong>Total Pengiriman</strong>
                            <span>Rp <?php echo e(number_format($summary->shipping_cost ?? 0, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <strong>Pajak (10%)</strong>
                            <span>Rp <?php echo e(number_format($summary->tax_amount ?? 0, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between fw-bold fs-5">
                            <strong>Total Pesanan</strong>
                            <span class="text-kpop-accent">Rp <?php echo e(number_format($summary->total_amount ?? 0, 0, ',', '.')); ?></span>
                        </li>
                    </ul>
                    <hr class="my-4">
                    <div class="d-grid gap-2">
                        <a href="<?php echo e(route('checkout.process')); ?>" class="btn btn-kpop btn-lg" type="button">Buat Pesanan</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $attributes = $__attributesOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__attributesOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $component = $__componentOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__componentOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/checkout/index.blade.php ENDPATH**/ ?>