<?php if (isset($component)) { $__componentOriginalfbdd260259317c02d12d73257650e0d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbdd260259317c02d12d73257650e0d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mainlayout','data' => ['title' => 'K-Pop Mart Keranjang Belanja']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mainlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'K-Pop Mart Keranjang Belanja']); ?>
    <main class="container my-5">
        <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['items' => [
            ['label' => 'Produk', 'url' => route('products.index')],
            ['label' => 'Keranjang', 'url' => route('cart.index')],
        ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

        <h1 class="mb-4">Keranjang Belanja</h1>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm p-3">
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col" class="text-center">Harga</th>
                                    <th scope="col" class="text-center">Jumlah</th>
                                    <th scope="col" class="text-end">Total</th>
                                    <th scope="col" class="text-end">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr data-item-price="<?php echo e($item->product->price); ?>" data-item-id="<?php echo e($item->id); ?>">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo e(asset('storage/image/' . $item->product->image)); ?>" class="cart-item-img rounded me-3" width="150px" alt="<?php echo e($item->product->name); ?>">
                                            <div>
                                                <h6 class="mb-0"><?php echo e($item->product->name); ?></h6>
                                                <small class="text-muted"><?php echo e(Str::limit($item->product->description, 30)); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center">Rp <?php echo e(number_format($item->product->price, 0, ',', '.')); ?></td>
                                    <td class="text-center">
                                        <?php echo e($item->quantity); ?>

                                    </td>
                                    <td class="text-end fw-bold item-total">Rp <?php echo e(number_format($item->product->price * $item->quantity, 0, ',', '.')); ?></td>
                                    <td class="text-end d-flex gap-2 justify-content-end">
                                        <!-- Tombol Checkout Per Item -->
                                        <form action="<?php echo e(route('checkout.singleItem', $item->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success btn-sm">Checkout</button>
                                        </form>
                                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editQuantityModal-<?php echo e($item->id); ?>">Edit</button>

                                        <!-- Modal Edit Quantity -->
                                        <div class="modal fade" id="editQuantityModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="editQuantityModalLabel-<?php echo e($item->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="editQuantityModalLabel-<?php echo e($item->id); ?>">Edit Jumlah Produk</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <div class="modal-body">
                                                            <div class="mb-3">
                                                                <label for="quantity-<?php echo e($item->id); ?>" class="form-label">Jumlah untuk <strong><?php echo e($item->product->name); ?></strong>:</label>
                                                                <input type="number" class="form-control" id="quantity-<?php echo e($item->id); ?>" name="quantities[<?php echo e($item->id); ?>]" value="<?php echo e($item->quantity); ?>" min="0">
                                                            </div>
                                                            <p class="text-danger small mt-2">Item dengan kuantitas 0 akan dihapus dari keranjang.</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">Keranjang Anda kosong.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Ringkasan Pesanan Dihapus -->
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $attributes = $__attributesOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__attributesOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $component = $__componentOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__componentOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?>
<?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/cart.blade.php ENDPATH**/ ?>