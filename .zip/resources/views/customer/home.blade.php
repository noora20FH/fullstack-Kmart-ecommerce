<x-homelayout title="K-Mart Customer Home">
@push('nav-logged-in')
                <div class="d-flex">
                   
                    <a href="#" class="btn btn-outline-light me-2">
                        <i class="bi bi-cart"></i> </a>
                    <a href="#" class="btn btn-outline-light ms-2"><i class="bi bi-person-circle"></i> Profile</a>
                </div>
                @endpush
</x-homelayout>