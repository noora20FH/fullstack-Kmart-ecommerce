<a href="<?php echo e(route('products.show', $productId)); ?>" 
   class="btn" 
   style="background-color: #7B68EE; border-color: #7B68EE; color: white;"
   x-data
   x-on:click.prevent="
        fetch('<?php echo e(route('products.click', $productId)); ?>', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Content-Type': 'application/json'
            }
        }).then(response => {
            // Anda bisa menambahkan logika di sini setelah berhasil mencatat klik
            // Contoh: console.log('Klik berhasil dicatat!');
            window.location.href = '<?php echo e(route('products.show', $productId)); ?>';
        });
   "
>
    Lihat Detail
</a><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/components/details-product-button.blade.php ENDPATH**/ ?>