<?php if (isset($component)) { $__componentOriginalfbdd260259317c02d12d73257650e0d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbdd260259317c02d12d73257650e0d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mainlayout','data' => ['title' => 'Daftar Pesanan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mainlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Daftar Pesanan']); ?>
    <main class="container my-5">
        <h1 class="text-center mb-5 fw-bold" style="color: #7B68EE;">Daftar Pesanan</h1>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h4 class="card-title fw-bold">Pesanan #<?php echo e($order->id); ?></h4>
                                <p class="card-text text-muted mb-0">Tanggal Pesanan: <?php echo e(\Carbon\Carbon::parse($order->created_at)->locale('id')->isoFormat('D MMMM Y')); ?></p>
                            </div>
                            <?php
                            $statusClass = [
                            'pending' => 'warning text-dark',
                            'completed' => 'success',
                            'failed' => 'danger',
                            ][strtolower($order->status)] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo e($statusClass); ?> fs-6 px-3 py-2"><?php echo e(ucfirst($order->status)); ?></span>
                        </div>
                        <hr>

                        
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <h6 class="mb-0"><?php echo e($item->product->name ?? 'Produk Dihapus'); ?></h6>
                                <small class="text-muted">Jumlah: <?php echo e($item->quantity); ?></small>
                            </div>
                            <span class="fw-bold">Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr>

                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <h5 class="mb-0">Total Pembayaran</h5>
                            <h4 class="mb-0 fw-bold" style="color: #FFC107;">Rp <?php echo e(number_format($order->total_payment, 0, ',', '.')); ?></h4>
                        </div>
                        <div class="d-grid mt-3 gap-2">

                            <a href="<?php echo e(route('order.message', ['orderId' => $order->id])); ?>" class="btn btn-primary">
                                Lakukan Pembayaran
                            </a>

                            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#detailModal-<?php echo e($order->id); ?>">
                                Lihat Detail Pesanan
                            </button>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-info text-center" role="alert">
                    Anda belum memiliki riwayat pesanan.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal untuk Detail Pesanan -->
    <div class="modal fade" id="detailModal-<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="detailModalLabel-<?php echo e($order->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="detailModalLabel-<?php echo e($order->id); ?>">Detail Pesanan #<?php echo e($order->id); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php
                    $statusMapping = [
                    'pending' => 'warning text-dark',
                    'completed' => 'success',
                    'failed' => 'danger',
                    ];
                    $statusColor = $statusMapping[strtolower($order->status)] ?? 'secondary';
                    ?>
                    <h4 class="fw-bold">
                        Status Pesanan:
                        <span class="badge bg-<?php echo e($statusColor); ?>">
                            <?php echo e(ucfirst($order->status)); ?>

                        </span>
                    </h4>
                    <p class="text-muted">Tanggal Pesanan: <?php echo e(\Carbon\Carbon::parse($order->created_at)->locale('id')->isoFormat('D MMMM Y')); ?></p>
                    <hr>
                    <h6 class="fw-bold">Detail Pengiriman</h6>
                    <div>
                        <p><strong>Nama Penerima:</strong> <?php echo e($order->user->name ?? 'User Dihapus'); ?></p>
                        <p><strong>No. Telp:</strong> <?php echo e($order->customer_phone); ?></p>
                        <p><strong>Alamat:</strong> <?php echo e($order->customer_address); ?></p>
                    </div>

                    <hr>
                    <h6 class="fw-bold">Item Pesanan</h6>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Produk</th>
                                    <th scope="col">Jumlah</th>
                                    <th scope="col">Harga Satuan</th>
                                    <th scope="col" class="text-end">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->product->name ?? 'Produk Dihapus'); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td>Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                                    <td class="text-end">Rp <?php echo e(number_format($item->price * $item->quantity, 0, ',', '.')); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <hr>
                    <h6 class="fw-bold">Ringkasan Pembayaran</h6>
                    <ul class="list-group list-group-flush mb-3">
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Subtotal Produk</span>
                            <span>Rp <?php echo e(number_format($order->subtotal_amount, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Pajak (10%)</span>
                            <span>Rp <?php echo e(number_format($order->tax_amount, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Biaya Pengiriman</span>
                            <span>Rp <?php echo e(number_format($order->shipping_fee, 0, ',', '.')); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between fw-bold">
                            <span>Total Pembayaran</span>
                            <span class="text-success">Rp <?php echo e(number_format($order->total_payment, 0, ',', '.')); ?></span>
                        </li>
                    </ul>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $attributes = $__attributesOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__attributesOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $component = $__componentOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__componentOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/orders/index.blade.php ENDPATH**/ ?>