<?php if (isset($component)) { $__componentOriginalfbdd260259317c02d12d73257650e0d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbdd260259317c02d12d73257650e0d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mainlayout','data' => ['title' => 'Manajemen Pesanan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mainlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Manajemen Pesanan']); ?>

    <main class="container my-5">
        <h1 class="mb-4">Manajemen Pesanan</h1>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Pelanggan</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Total</th>
                        <th scope="col">Metode Pembayaran</th>
                        <th scope="col">Status</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row">#<?php echo e($order->id); ?></th>
                        <td><?php echo e($order->user->name ?? 'User Dihapus'); ?></td>
                        <td><?php echo e($order->created_at->format('d M, Y H:i')); ?></td>
                        <td>Rp <?php echo e(number_format($order->total_payment, 0, ',', '.')); ?></td>
                        <td><?php echo e(ucfirst($order->payment_method)); ?></td>
                        <td>
                            <?php
                                $statusClass = [
                                    'pending' => 'warning',
                                    'completed' => 'success',
                                    'failed' => 'danger',
                                ][$order->status] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo e($statusClass); ?> text-dark"><?php echo e(ucfirst($order->status)); ?></span>
                        </td>
                        <td>
                            
                            <button type="button" class="btn btn-sm btn-warning edit-status-btn"
                                data-bs-toggle="modal"
                                data-bs-target="#editStatusModal"
                                data-order-id="<?php echo e($order->id); ?>"
                                data-current-status="<?php echo e($order->status); ?>">
                                Edit Status
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada pesanan yang tersedia.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="justify-content-between align-items-center mt-4">
            <?php echo e($orders->links('pagination::bootstrap-5')); ?>

        </div>
    </main>

    <div class="modal fade" id="editStatusModal" tabindex="-1" aria-labelledby="editStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editStatusModalLabel">Edit Status Pesanan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <form id="editStatusForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="modal-body">
                        <input type="hidden" id="modalOrderId" name="order_id">
                        <div class="mb-3">
                            <label for="statusSelect" class="form-label">Status</label>
                            <select class="form-select" id="statusSelect" name="status">
                                <option value="pending">Pending</option>
                                <option value="completed">Completed</option>
                                <option value="failed">Failed</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Perbarui Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const editStatusModal = document.getElementById('editStatusModal');
            editStatusModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const orderId = button.getAttribute('data-order-id');
                const currentStatus = button.getAttribute('data-current-status');
                const modalForm = document.getElementById('editStatusForm');
                const statusSelect = document.getElementById('statusSelect');

                // Masukkan ID dan status saat ini ke dalam modal
                statusSelect.value = currentStatus;

                // Perbarui URL form action dengan ID pesanan
                modalForm.action = `/admin/orders/${orderId}/update-status`;
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $attributes = $__attributesOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__attributesOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $component = $__componentOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__componentOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>