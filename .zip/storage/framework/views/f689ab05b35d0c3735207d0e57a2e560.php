<?php if (isset($component)) { $__componentOriginalfbdd260259317c02d12d73257650e0d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbdd260259317c02d12d73257650e0d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mainlayout','data' => ['title' => 'K-Pop Mart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mainlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'K-Pop Mart']); ?>

<?php if (isset($component)) { $__componentOriginalc006f4fce3515260a920bc5121856ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc006f4fce3515260a920bc5121856ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.statusInfo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('statusInfo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc006f4fce3515260a920bc5121856ac0)): ?>
<?php $attributes = $__attributesOriginalc006f4fce3515260a920bc5121856ac0; ?>
<?php unset($__attributesOriginalc006f4fce3515260a920bc5121856ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc006f4fce3515260a920bc5121856ac0)): ?>
<?php $component = $__componentOriginalc006f4fce3515260a920bc5121856ac0; ?>
<?php unset($__componentOriginalc006f4fce3515260a920bc5121856ac0); ?>
<?php endif; ?>

    <main class="container my-5">
        <h1 class="mb-4">Daftar Produk</h1>
        <a href="<?php echo e(route('admin-products.create')); ?>" class="btn btn-primary mb-3">Tambah Produk Baru</a>

        
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Nama Produk</th>
                        <th scope="col">Grup</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Stok</th>
                        <th scope="col">Gambar</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->group); ?></td>
                            <td><?php echo e($product->category->name); ?></td> 
                            <td>Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                            <td><?php echo e($product->stock); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/image/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="img-thumbnail" style="width: 150px;">
                            </td>
                            <td><?php echo e(Str::limit($product->description, 50)); ?></td>
                            <td class="d-flex gap-2">
                                
                                <a href="<?php echo e(route('admin-products.edit', $product->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                                
                                <form action="<?php echo e(route('admin-products.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">Belum ada produk yang tersedia.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="justify-content-between align-items-center mt-4">
            <?php echo e($products->links('pagination::bootstrap-5')); ?>

        </div>
        


    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $attributes = $__attributesOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__attributesOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbdd260259317c02d12d73257650e0d9)): ?>
<?php $component = $__componentOriginalfbdd260259317c02d12d73257650e0d9; ?>
<?php unset($__componentOriginalfbdd260259317c02d12d73257650e0d9); ?>
<?php endif; ?><?php /**PATH E:\Projects\Eduwork\programming-tasks\ecommerce-laravel\resources\views/admin/products/index.blade.php ENDPATH**/ ?>